/*
    DDL Drop Tables 
    Nicola Maraschi 20041040
    Daniele Porcelli 20039368
    */

DROP TABLE Cittadino CASCADE; 

DROP TABLE GreenPass CASCADE;

DROP TABLE Tampone CASCADE;

DROP TABLE Infezione CASCADE;

DROP TABLE Appuntamento CASCADE;

DROP TABLE Report CASCADE;

DROP TABLE Lotto CASCADE;

DROP TABLE Appartiene CASCADE;

DROP TABLE Medico CASCADE;

DROP TABLE Patologie CASCADE;

DROP TABLE Vaccino CASCADE;

DROP TABLE CentroVaccinale CASCADE;

/*
DROP TABLE Esegue CASCADE;
*/