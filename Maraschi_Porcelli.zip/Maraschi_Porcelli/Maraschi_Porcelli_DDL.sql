
/*
    DDL creazione tabelle
    Nicola Maraschi 20041040
    Daniele Porcelli 20039368
*/

CREATE TABLE GreenPass
(
	Id_Pass VARCHAR(10) PRIMARY KEY,
	Data DATE NOT NULL,
	Validit� BOOLEAN NOT NULL,
	Data_Inizio_Sosp DATE NULL,
	Data_Fine_Sosp DATE NULL
);

CREATE TABLE Tampone
(
	Id_Tampone VARCHAR(10) PRIMARY KEY,
	Data DATE NOT NULL,
	Luogo VARCHAR(50) NOT NULL,
	Esito VARCHAR(20) NOT NULL CHECK (( Esito = 'Positivo') OR (Esito = 'Negativo'))
);

CREATE TABLE Infezione
(
	Id_Infez VARCHAR(10) PRIMARY KEY,
	Data_Inizio_Infez DATE NOT NULL,
	Data_Inizio_Ric DATE NOT NULL,
	Data_Fine_Ric DATE NULL,
	Data_Fine_Guar DATE NULL
);

CREATE TABLE Lotto
(
	numLotto VARCHAR(10) PRIMARY KEY,
	Data_Scadenza DATE NOT NULL,
	Data_Produz DATE NOT NULL,
	Paese VARCHAR(20) NOT NULL,
	Reazione VARCHAR(20) NULL
);

CREATE TABLE Patologie
(
	Id_Patologia VARCHAR(10) PRIMARY KEY,
	InCorso VARCHAR(5) NOT NULL CHECK ((Incorso = 'Si') OR (Incorso = 'No')),
	Pregresse VARCHAR(5) NOT NULL CHECK ((Pregresse = 'Si') OR (Pregresse = 'No')),
	Descrizione VARCHAR(50) NOT NULL CHECK ((Descrizione = 'allergia') OR (Descrizione = 'intolleranza alimentare') OR (Descrizione = 'problema respiratorio') OR (Descrizione = 'problema cardiaco') OR (Descrizione = 'operazione chirurgica'))

);

CREATE TABLE Vaccino
(
	Cod_Vaccino VARCHAR(20) PRIMARY KEY,
	Nome VARCHAR(20) NOT NULL,
	Efficacia DECIMAL(6,2) NOT NULL,
	Eta_Min NUMERIC(2) CHECK (Eta_min >= 6),
	Eta_Max NUMERIC(2) CHECK (Eta_Max <= 90)
);

CREATE TABLE CentroVaccinale
(
	Id_Centro VARCHAR(10) PRIMARY KEY,
	Nome VARCHAR(20) NOT NULL,
	Regione VARCHAR(50) NOT NULL,
	Citt� VARCHAR(50) NOT NULL,
	numeroVaccinazioni INTEGER NOT NULL,
	nome_Vaccino VARCHAR(50) NOT NULL,
	numLotto VARCHAR(10) NOT NULL,
	FOREIGN KEY (numLotto) REFERENCES Lotto(numLotto)
);

CREATE TABLE Report
(
	Id_Report VARCHAR(10) PRIMARY KEY,
	Avversit� VARCHAR(40) NOT NULL,
	nome_CentroVac VARCHAR(40) NOT NULL,
	Data DATE NOT NULL,
	nome_Vaccino VARCHAR(20) NOT NULL,
	nome_Medico VARCHAR(20) NOT NULL,
	numLotto VARCHAR(10) NOT NULL,
	FOREIGN KEY (numLotto) REFERENCES Lotto(numLotto)
	
);

CREATE TABLE Appartiene
(
	Cod_Vaccino VARCHAR(20) NOT NULL,
	numLotto VARCHAR(10) NOT NULL,
	CONSTRAINT AppartieneKey PRIMARY KEY (Cod_Vaccino,numLotto)

);

CREATE TABLE Appuntamento
(
	Id_Appunt VARCHAR(10) PRIMARY KEY,
	data DATE NOT NULL,
	nome_CentroVacc VARCHAR(20) NOT NULL,
	Telefono VARCHAR(15) NULL,
	Email VARCHAR(20) NULL,
	nome_Vaccino VARCHAR(20) NOT NULL,
	num_Dosi INTEGER DEFAULT 0,
	Id_Report VARCHAR(10) NOT NULL,
	FOREIGN KEY (id_Report) REFERENCES Report(id_Report),
	Id_Pass VARCHAR(10) NOT NULL,
	FOREIGN KEY (id_Pass) REFERENCES GreenPass(id_Pass)
);

CREATE TABLE Cittadino
(
	CF VARCHAR(20) PRIMARY KEY,
	Nome VARCHAR(20) NOT NULL,
	Cognome VARCHAR(20) NOT NULL,
	DataNascita DATE NOT NULL,
	Indirizzo VARCHAR(20) NOT NULL,
	Categoria VARCHAR(50) NOT NULL CHECK ((Categoria = 'Personale Sanitario') OR (Categoria = 'Personale Scolastico/Universitario') OR (Categoria = 'cittadino semplice')),
	Id_Patologia VARCHAR(10) NOT NULL,
	FOREIGN KEY (id_Patologia) REFERENCES Patologie(id_Patologia),
	Id_Tampone VARCHAR(10) NOT NULL,
	FOREIGN KEY (id_Tampone) REFERENCES Tampone(id_Tampone),
	Id_Appunt VARCHAR(10) NOT NULL,
	FOREIGN KEY (id_Appunt) REFERENCES Appuntamento(id_Appunt),
	Id_Infez VARCHAR(10) NOT NULL,
	FOREIGN KEY (id_Infez) REFERENCES Infezione(id_Infez)
);

CREATE TABLE Medico
(
	Id_Medico VARCHAR(10) PRIMARY KEY,
	Nome VARCHAR(20) NOT NULL,
	Cognome VARCHAR(20) NOT NULL,
	DataNascita Date NOT NULL,
	Specializzazione VARCHAR(40) NOT NULL CHECK ( (Specializzazione = 'medico base') OR (Specializzazione = 'Infermiere' )),
	CF VARCHAR(20) NOT NULL,
	FOREIGN KEY (CF) REFERENCES Cittadino(CF),
	Cod_Vaccino VARCHAR(20) NOT NULL,
FOREIGN KEY (Cod_Vaccino) REFERENCES Vaccino(Cod_Vaccino),
	Id_Centro VARCHAR(10) NOT NULL,
	FOREIGN KEY (Id_Centro) REFERENCES CentroVaccinale(Id_Centro)
);











