/*
    DML di modifica
	Nicola Maraschi 20041040
	Daniele Porcelli 20039368
    */

/*Cancellazione Infezione di id_infez 'I5'*/
    DELETE FROM infezione
    WHERE id_infez = 'I5';

/*Aggiunta nuovo GreenPass*/

INSERT INTO GreenPass VALUES('G5','15-07-2022','TRUE',NULL,NULL);

/*Modifica valore num_dosi +1*/
    
    UPDATE Appuntamento
        SET num_dosi = num_dosi + 1
        WHERE id_appunt = 'A3';