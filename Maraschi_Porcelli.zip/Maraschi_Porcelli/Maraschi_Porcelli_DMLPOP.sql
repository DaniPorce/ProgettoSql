/*
    DML di popolazione tabelle
    Nicola Maraschi 20041040
    Daniele Porcelli 20039368
*/

INSERT INTO GreenPass VALUES ('G1','12-03-2022','TRUE',NULL,NULL);
INSERT INTO GreenPass VALUES ('G2','15-06-2022','FALSE','13-03-2022','13-04-2022');
INSERT INTO GreenPass VALUES ('G3','19-02-2022','TRUE',NULL,NULL);
INSERT INTO GreenPass VALUES ('G4','11-06-2022','FALSE','12-06-2022','12-07-2022');

INSERT INTO Tampone VALUES ('T1','17-03-2022','Farmacia Comunale 1','Negativo');
INSERT INTO Tampone VALUES ('T2','16-07-2022','Farmacia Comunale 2','Positivo');
INSERT INTO Tampone VALUES ('T3','17-08-2022','Farmacia Comunale 3','Negativo');
INSERT INTO Tampone VALUES ('T4','17-11-2022','Farmacia Comunale 4','Positivo');

INSERT INTO Infezione VALUES ('I1','12-03-2022','13-03-2022','15-03-2022','16-03-2022');
INSERT INTO Infezione VALUES ('I2','13-04-2022','14-04-2022',NULL,NULL);
INSERT INTO Infezione VALUES ('I3','14-05-2022','15-05-2022','17-05-2022','18-05-2022');
INSERT INTO Infezione VALUES ('I4','15-06-2022','16-06-2022',NULL,NULL);
INSERT INTO Infezione VALUES ('I5','16-07-2022','17-07-2022','19-07-2022','20-07-2022');


INSERT INTO Lotto VALUES 
('L1','12-03-2022','9-12-2021','Italia','allergia');
INSERT INTO Lotto VALUES 
('L2','15-07-2022','12-06-2021','Bolivia',NULL);
INSERT INTO Lotto VALUES 
('L3','17-08-2022','5-07-2021','Spagna','dolori muscolari');
INSERT INTO Lotto VALUES 
('L4','18-07-2022','4-08-2021','America',NULL);

INSERT INTO Patologie VALUES 
('P1','Si','No','allergia');
INSERT INTO Patologie VALUES 
('P2','No','Si','intolleranza alimentare');
INSERT INTO Patologie VALUES 
('P3','No','No','problema respiratorio');
INSERT INTO Patologie VALUES 
('P4','Si','Si','problema cardiaco');

INSERT INTO Vaccino VALUES 
('COD1','COVIDIN',80,10,70);
INSERT INTO Vaccino VALUES 
('COD2','CORONAX',100,6,40);
INSERT INTO Vaccino VALUES 
('COD3','FLUSTOP',60,18,30);
INSERT INTO Vaccino VALUES 
('COD4','COVIDIN',50,12,50);

INSERT INTO CentroVaccinale VALUES 
('V1','Centro Vaccinale A','Piemonte','Vercelli','1200','COVIDIN','L1');
INSERT INTO CentroVaccinale VALUES 
('V2','Centro Vaccinale B','Lombardia','Milano','1300','CORONAX','L2');
INSERT INTO CentroVaccinale VALUES 
('V3','Centro Vaccinale C','Liguria','Genova','1400','FLUSTOP','L1');
INSERT INTO CentroVaccinale VALUES 
('V4','Centro Vaccinale D','Trentino Alto Adige','Trento','1500','COVIDIN','L2');

INSERT INTO Report VALUES 
('R1','allergia','Centro Vaccinale A','12-03-2022','COVIDIN','Giovanni','L1');
INSERT INTO Report VALUES 
('R2','anafilassi','Centro Vaccinale B','14-06-2022','FLUSTOP','Marco','L2');
INSERT INTO Report VALUES 
('R3','episodi sincopali','Centro Vaccinale C','15-05-2022','CORONAX','Luigi','L3');
INSERT INTO Report VALUES 
('R4','shock anafilattico','Centro Vaccinale D','18-08-2022','COVIDIN','Fabio','L4');

INSERT INTO Appartiene VALUES 
('COD1','L1');
INSERT INTO Appartiene VALUES 
('COD2','L2');
INSERT INTO Appartiene VALUES 
('COD3','L1');
INSERT INTO Appartiene VALUES 
('COD4','L3');

INSERT INTO Appuntamento VALUES
('A1','12-03-2022','Centro Vaccinale A','3946573847',NULL,'CORONAX',1,'R1','G1');
INSERT INTO Appuntamento VALUES
('A2','15-04-2022','Centro Vaccinale B',NULL,'paolo@gmail.com','COVIDIN',2,'R2','G2');
INSERT INTO Appuntamento VALUES
('A3','16-05-2022','Centro Vaccinale C','4736485746','datti@gmail.com','FLUSTOP',0,'R3','G3');
INSERT INTO Appuntamento VALUES
('A4','17-06-2022','Centro Vaccinale D',NULL,NULL,'COVIDIN',0,'R1','G4');
INSERT INTO Appuntamento VALUES
('A5','18-07-2022','Centro Vaccinale E','36473526273',NULL,'CORONAX',3,'R2','G1');

INSERT INTO Cittadino VALUES
('ABC','Gianni','Pasolini','4-06-2001','Via Gianni morandi ','cittadino semplice','P1','T1','A1','I1');
INSERT INTO Cittadino VALUES
('BCD','Giacomo','Fanciullo','12-08-2001','Via Eurosatellite','Personale Sanitario','P2','T2','A2','I2');
INSERT INTO Cittadino VALUES
('EFG','Nanni','Ferrari','7-10-2001','Via Stati Uniti','Personale Scolastico/Universitario','P3','T3','A3','I3');
INSERT INTO Cittadino VALUES
('GHI','Pino','Guanti','14-01-2001','Via Ferrari','cittadino semplice','P4','T4','A4','I4');

INSERT INTO Medico VALUES
('M1','Giovanni','Lillo','12-07-2003','medico base','ABC','COD1','V1');
INSERT INTO Medico VALUES
('M2','Marco','Catania','13-05-1994','Infermiere','BCD','COD2','V2');
INSERT INTO Medico VALUES
('M3','Luigi','Tornato','12-06-1995','medico base','GHI','COD1','V3');
INSERT INTO Medico VALUES
('M4','Fabio','Biuio','13-07-1990','Infermiere','EFG','COD3','V1');










